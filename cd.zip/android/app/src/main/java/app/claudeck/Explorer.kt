package app.claudeck

import app.claudeck.domain.usecase.BackAction
import app.claudeck.domain.usecase.BarAction
import app.claudeck.domain.usecase.ExplorerRules
import app.claudeck.domain.usecase.ItemAction
import app.claudeck.domain.usecase.PickFilter
import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.graphics.Outline
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import java.io.File

/** Lo que el explorador le pide a la pantalla principal. */
interface ExplorerHost {
    fun surface(): Int
    fun onSurface(): Int
    fun accent(): Int
    fun border(): Int
    fun close()
    fun message(text: String)
    fun requestLegacyPermission()

    /** Desde el modo «subir archivo»: volver al selector de archivos del sistema. */
    fun systemPicker()
}

/**
 * Explorador de archivos interno: un cajón grande con la estética de la app. Permite entrar en carpetas,
 * abrir archivos, seleccionar varios (mantener apretado), copiar, mover, renombrar, borrar, crear
 * carpetas y extraer .zip. Se arma entero en código; `view` se agrega al contenedor de la pantalla.
 */
class FileExplorer(private val act: AppCompatActivity, private val host: ExplorerHost) {
    val view: LinearLayout = LinearLayout(act)

    private val storageRoot: File = Environment.getExternalStorageDirectory()
    private val downloads: File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    private var dir: File = if (downloads.exists()) downloads else storageRoot
    private var sort = SortMode.DATE
    private var entries: List<FileEntry> = emptyList()
    private val selected = LinkedHashSet<File>()
    private var clip: List<File> = emptyList()
    private var clipCut = false

    private val onSurface = host.onSurface()
    private val muted = ColorUtils.setAlphaComponent(host.onSurface(), 150)
    private val accent = host.accent()

    private lateinit var upButton: ImageButton
    private lateinit var titleView: TextView
    private lateinit var pathView: TextView
    private lateinit var bar: LinearLayout
    private lateinit var progress: LinearProgressIndicator
    private lateinit var list: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var permView: LinearLayout
    private val adapter = Adapter()

    /** Modo «subir archivo»: una página pidió adjuntar archivos y se eligen acá (varios a la vez). */
    private class PickRequest(val accept: List<String>, val onDone: (List<File>?) -> Unit)
    private var pick: PickRequest? = null
    private var touchX = 0
    private var touchY = 0
    private var menu: android.widget.PopupWindow? = null

    init {
        build()
    }

    /** Cambia el color del borde del cajón (sigue a la cuenta activa). */
    fun setBorder(color: Int) {
        (view.background as? GradientDrawable)?.setStroke(dp(3), color)
    }

    private fun dp(v: Int): Int = (v * act.resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- Construcción

    private fun build() {
        val r = dp(22).toFloat()
        view.orientation = LinearLayout.VERTICAL
        view.elevation = dp(8).toFloat()
        view.isClickable = true // que los toques no pasen al WebView de atrás
        view.visibility = View.GONE
        view.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setColor(host.surface())
            setStroke(dp(3), host.border())
        }
        view.clipToOutline = true
        view.setPadding(0, dp(10), 0, 0)

        // Cabecera: subir · nombre de la carpeta y ruta · cerrar
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(8), 0, dp(8), dp(4))
        upButton = iconButton(R.drawable.ic_back, "Subir una carpeta") { goUp() }
        head.addView(upButton, LinearLayout.LayoutParams(dp(44), dp(44)))
        val texts = LinearLayout(act)
        texts.orientation = LinearLayout.VERTICAL
        titleView = TextView(act)
        titleView.textSize = 18f
        titleView.setTypeface(titleView.typeface, android.graphics.Typeface.BOLD)
        titleView.setTextColor(onSurface)
        titleView.maxLines = 1
        titleView.ellipsize = TextUtils.TruncateAt.END
        pathView = TextView(act)
        pathView.textSize = 12f
        pathView.setTextColor(muted)
        pathView.maxLines = 1
        pathView.ellipsize = TextUtils.TruncateAt.START
        texts.addView(titleView)
        texts.addView(pathView)
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(4)
            marginEnd = dp(4)
        })
        head.addView(iconButton(R.drawable.ic_close, "Cerrar el explorador") { host.close() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        view.addView(head)

        // Barra de acciones (cambia si hay selección).
        val scroll = HorizontalScrollView(act)
        scroll.isHorizontalScrollBarEnabled = false
        bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(12), dp(4), dp(12), dp(8))
        scroll.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        view.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        progress = LinearProgressIndicator(act)
        progress.isIndeterminate = true
        progress.setIndicatorColor(accent)
        progress.visibility = View.INVISIBLE
        view.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Lista + estados vacío / sin permiso.
        val body = FrameLayout(act)
        list = RecyclerView(act)
        list.layoutManager = LinearLayoutManager(act)
        list.adapter = adapter
        list.clipToPadding = false
        list.setPadding(0, 0, 0, dp(12))
        body.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        emptyView = TextView(act)
        emptyView.text = "Carpeta vacía"
        emptyView.textSize = 15f
        emptyView.setTextColor(muted)
        emptyView.gravity = Gravity.CENTER
        emptyView.visibility = View.GONE
        body.addView(emptyView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        permView = LinearLayout(act)
        permView.orientation = LinearLayout.VERTICAL
        permView.gravity = Gravity.CENTER
        permView.setPadding(dp(32), dp(16), dp(32), dp(16))
        permView.visibility = View.GONE
        val permText = TextView(act)
        permText.text = "Para ver y administrar tus archivos, AlternAIs necesita acceso a los archivos del dispositivo."
        permText.textSize = 15f
        permText.setTextColor(onSurface)
        permText.gravity = Gravity.CENTER
        permView.addView(permText)
        val permBtn = MaterialButton(act)
        permBtn.text = "Dar permiso"
        permBtn.setOnClickListener { askPermission() }
        permView.addView(permBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(16)
        })
        body.addView(permView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        view.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun iconButton(icon: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(act)
        b.setImageResource(icon)
        b.imageTintList = android.content.res.ColorStateList.valueOf(accent)
        b.setBackgroundResource(selectableBg())
        b.contentDescription = desc
        b.setOnClickListener { onClick() }
        return b
    }

    private fun selectableBg(): Int {
        val tv = android.util.TypedValue()
        act.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun chip(label: String, icon: Int, onClick: () -> Unit): TextView {
        val tv = TextView(act)
        tv.text = label
        tv.textSize = 13f
        tv.setTextColor(onSurface)
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setPadding(dp(12), dp(8), dp(14), dp(8))
        AppCompatResources.getDrawable(act, icon)?.mutate()?.let {
            it.setTint(accent)
            it.setBounds(0, 0, dp(18), dp(18))
            tv.setCompoundDrawablesRelative(it, null, null, null)
        }
        tv.compoundDrawablePadding = dp(6)
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), ColorUtils.setAlphaComponent(onSurface, 60))
            setColor(ColorUtils.setAlphaComponent(accent, 0x1A))
        }
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun addChip(c: TextView) {
        bar.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = dp(8)
        })
    }

    // ---------------------------------------------------------------- Permiso

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(act, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${act.packageName}")))
            } catch (_: Exception) {
                try {
                    act.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (_: Exception) {
                    host.message("Activá el acceso a todos los archivos para AlternAIs en los ajustes del sistema")
                }
            }
        } else {
            host.requestLegacyPermission()
        }
    }

    // ---------------------------------------------------------------- Navegación

    /** Al abrir el cajón: muestra la carpeta actual (Descargas la primera vez). */
    fun open() = refresh()

    fun isPicking(): Boolean = pick != null

    fun startPick(accept: List<String>, onDone: (List<File>?) -> Unit) {
        pick?.onDone?.invoke(null)
        pick = PickRequest(accept.filter { it.isNotBlank() }, onDone)
        selected.clear()
        refresh()
    }

    /** Se cerró el explorador (o se cambió de cajón) sin elegir: la página recibe «ningún archivo». */
    fun cancelPick() {
        val p = pick ?: return
        pick = null
        selected.clear()
        p.onDone(null)
        refresh()
    }

    /** Suelta el pedido sin avisar a la página (la va a atender el selector del sistema). */
    fun dropPick() {
        pick = null
        selected.clear()
        refresh()
    }

    private fun finishPick() {
        val p = pick ?: return
        val files = selected.toList()
        pick = null
        selected.clear()
        p.onDone(files)
        host.close()
    }

    private fun acceptable(e: FileEntry): Boolean {
        val acc = pick?.accept ?: return true
        return PickFilter.accepts(acc, e.file.name, e.isDir) { ext -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "" }
    }

    fun refresh() {
        if (!hasAccess()) {
            entries = emptyList()
            adapter.notifyDataSetChanged()
            permView.visibility = View.VISIBLE
            emptyView.visibility = View.GONE
            list.visibility = View.GONE
            renderHeader()
            renderBar()
            return
        }
        permView.visibility = View.GONE
        list.visibility = View.VISIBLE
        val l = FileOps.list(dir, sort)
        if (l == null) {
            entries = emptyList()
            emptyView.text = "No se puede leer esta carpeta"
        } else {
            entries = if (pick != null) l.filter { acceptable(it) } else l
            emptyView.text = "Carpeta vacía"
        }
        selected.retainAll(entries.map { it.file }.toSet())
        emptyView.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
        renderHeader()
        renderBar()
    }

    private fun atRoot(): Boolean = dir.canonicalPath == storageRoot.canonicalPath

    private fun navigate(d: File) {
        dir = d
        selected.clear()
        refresh()
        list.scrollToPosition(0)
    }

    private fun goUp() {
        if (!atRoot()) dir.parentFile?.let { navigate(it) }
    }

    /** Atrás: sale de la selección o sube una carpeta. Devuelve false si no hay nada más que hacer (cerrar). */
    fun onBack(): Boolean = when (ExplorerRules.back(selected.isNotEmpty(), atRoot(), hasAccess())) {
        BackAction.CLEAR_SELECTION -> {
            selected.clear()
            adapter.notifyDataSetChanged()
            renderBar()
            true
        }
        BackAction.GO_UP -> {
            goUp()
            true
        }
        BackAction.CLOSE -> false
    }

    private fun renderHeader() {
        val root = atRoot()
        titleView.text = ExplorerRules.title(pick != null, root, dir.name)
        pathView.text = ExplorerRules.relativePath(dir.path, storageRoot.path)
        upButton.visibility = if (root) View.INVISIBLE else View.VISIBLE
    }

    private fun renderBar() {
        bar.removeAllViews()
        val only = selected.singleOrNull()
        val actions = ExplorerRules.barActions(
            hasAccess(), pick != null, selected.size,
            only != null && only.isFile && only.name.lowercase().endsWith(".zip"), clip.size
        )
        if (actions.isEmpty()) return
        if (pick == null && selected.isNotEmpty()) {
            val count = TextView(act)
            count.text = ExplorerRules.selectionCount(selected.size)
            count.textSize = 13f
            count.setTextColor(muted)
            count.gravity = Gravity.CENTER_VERTICAL
            count.setPadding(dp(4), 0, dp(12), 0)
            bar.addView(count, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        for (a in actions) {
            val label = ExplorerRules.barLabel(a, selected.size, clip.size, sort.label)
            when (a) {
                BarAction.PICK_UPLOAD -> addChip(chip(label, R.drawable.ic_upload) { finishPick() })
                BarAction.DOWNLOADS -> addChip(chip(label, R.drawable.ic_folder) { if (downloads.exists()) navigate(downloads) })
                BarAction.STORAGE -> addChip(chip(label, R.drawable.ic_folder) { navigate(storageRoot) })
                BarAction.SYSTEM_PICKER -> addChip(chip(label, R.drawable.ic_file) { host.systemPicker() })
                BarAction.CANCEL -> addChip(chip(label, R.drawable.ic_close) { host.close() })
                BarAction.COPY -> addChip(chip(label, R.drawable.ic_copy) { setClip(false) })
                BarAction.MOVE -> addChip(chip(label, R.drawable.ic_move) { setClip(true) })
                BarAction.RENAME -> addChip(chip(label, R.drawable.ic_edit) { only?.let { renameDialog(it) } })
                BarAction.EXTRACT -> addChip(chip(label, R.drawable.ic_zip) { only?.let { zipOptions(it) } })
                BarAction.DELETE -> addChip(chip(label, R.drawable.ic_trash) { deleteDialog(selected.toList()) })
                BarAction.SELECT_ALL -> addChip(chip(label, R.drawable.ic_select_all) {
                    selected.clear()
                    selected.addAll(entries.map { it.file })
                    adapter.notifyDataSetChanged()
                    renderBar()
                })
                BarAction.CANCEL_SELECTION -> addChip(chip(label, R.drawable.ic_close) { onBack() })
                BarAction.PASTE -> addChip(chip(label, R.drawable.ic_paste) { paste() })
                BarAction.DISCARD_CLIP -> addChip(chip(label, R.drawable.ic_close) {
                    clip = emptyList()
                    renderBar()
                })
                BarAction.NEW_FOLDER -> addChip(chip(label, R.drawable.ic_folder_plus) { newFolderDialog() })
                BarAction.SORT -> addChip(chip(label, R.drawable.ic_sort) {
                    sort = sort.next()
                    refresh()
                })
            }
        }
    }

    // ---------------------------------------------------------------- Acciones

    private fun setClip(cut: Boolean) {
        clip = selected.toList()
        clipCut = cut
        selected.clear()
        adapter.notifyDataSetChanged()
        renderBar()
        host.message(ExplorerRules.clipHint(cut, clip.size))
    }

    private fun busy(on: Boolean) {
        progress.visibility = if (on) View.VISIBLE else View.INVISIBLE
    }

    private fun runAsync(work: () -> String) {
        busy(true)
        Thread {
            val text = try {
                work()
            } catch (e: Exception) {
                ExplorerRules.failure(e.message, e.javaClass.simpleName)
            }
            act.runOnUiThread {
                busy(false)
                selected.clear()
                refresh()
                host.message(text)
            }
        }.start()
    }

    private fun paste() {
        val files = clip
        val cut = clipCut
        val target = dir
        if (cut) clip = emptyList()
        runAsync {
            var n = 0
            for (f in files) {
                if (cut) FileOps.move(f, target) else FileOps.copy(f, target)
                n++
            }
            ExplorerRules.pasteResult(cut, n)
        }
    }

    private fun deleteDialog(files: List<File>) {
        MaterialAlertDialogBuilder(act)
            .setTitle("Borrar")
            .setMessage(ExplorerRules.deleteQuestion(files.size, files[0].name))
            .setPositiveButton("Borrar") { _, _ ->
                runAsync {
                    var n = 0
                    for (f in files) {
                        if (f.deleteRecursively()) n++
                    }
                    ExplorerRules.deleteResult(n, files.size)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun textDialog(title: String, initial: String, positive: String, onOk: (String) -> Unit) {
        val input = TextInputEditText(act)
        input.setText(initial)
        input.setSingleLine(true)
        val dot = initial.lastIndexOf('.')
        input.setSelection(0, if (dot > 0) dot else initial.length)
        val holder = FrameLayout(act)
        holder.setPadding(dp(20), dp(8), dp(20), 0)
        holder.addView(input, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val dlg = MaterialAlertDialogBuilder(act)
            .setTitle(title)
            .setView(holder)
            .setPositiveButton(positive) { _, _ -> onOk(input.text?.toString().orEmpty()) }
            .setNegativeButton("Cancelar", null)
            .show()
        input.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    private fun renameDialog(f: File) {
        textDialog("Renombrar", f.name, "Renombrar") { name ->
            runAsync {
                val n = FileOps.rename(f, name)
                ExplorerRules.renamed(n.name)
            }
        }
    }

    private fun newFolderDialog() {
        textDialog("Nueva carpeta", "", "Crear") { name ->
            val parent = dir
            runAsync {
                val n = FileOps.mkdir(parent, name)
                ExplorerRules.folderCreated(n.name)
            }
        }
    }

    private fun zipOptions(zip: File) {
        val base = ExplorerRules.zipFolderName(zip.name)
        MaterialAlertDialogBuilder(act)
            .setTitle(zip.name)
            .setItems(arrayOf("Extraer en una carpeta «$base»", "Extraer aquí", "Abrir con otra app")) { _, which ->
                when (which) {
                    0 -> extract(zip, FileOps.uniqueFile(zip.parentFile ?: dir, base))
                    1 -> extract(zip, zip.parentFile ?: dir)
                    else -> openFile(zip)
                }
            }
            .show()
    }

    private fun extract(zip: File, dest: File) {
        runAsync {
            val n = FileOps.unzip(zip, dest)
            ExplorerRules.extracted(n, dest.name)
        }
    }

    /** Abre el archivo con la app que corresponda (o instala un .apk). `asText` lo fuerza como texto; `chooser` deja elegir app. */
    private fun openFile(f: File, asText: Boolean = false, chooser: Boolean = true) {
        try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".files", f)
            val ext = f.extension.lowercase()
            val mime = when {
                asText -> "text/plain"
                ext == "apk" -> "application/vnd.android.package-archive"
                else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            }
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(if (chooser && ext != "apk") Intent.createChooser(i, f.name) else i)
        } catch (_: ActivityNotFoundException) {
            host.message("No hay una app para abrir este archivo")
        } catch (e: Exception) {
            host.message("No se pudo abrir: " + (e.message ?: ""))
        }
    }

    // ---------------------------------------------------------------- Menú contextual (mantener apretado)

    private fun dismissMenu() {
        menu?.dismiss()
        menu = null
    }

    private fun showMenu(anchor: View, e: FileEntry) {
        dismissMenu()
        // Si el elemento está dentro de la selección, el menú actúa sobre toda la selección; si no, sobre él solo.
        val targets: List<File> = if (selected.contains(e.file)) selected.toList() else listOf(e.file)
        val multi = targets.size > 1
        val items = ArrayList<Triple<String, Int, () -> Unit>>()
        fun item(label: String, icon: Int, action: () -> Unit) {
            items.add(Triple(label, icon, action))
        }
        if (!multi) {
            val ext = e.file.extension.lowercase()
            if (e.isDir) {
                item("Abrir", R.drawable.ic_folder) { navigate(e.file) }
            } else if (ext == "apk") {
                item("Instalar", R.drawable.ic_download) { openFile(e.file, chooser = false) }
            } else {
                item("Abrir", R.drawable.ic_file) { if (e.isZip) zipOptions(e.file) else openFile(e.file) }
            }
            if (!e.isDir) {
                item("Abrir con…", R.drawable.ic_forward) { openFile(e.file) }
                item("Abrir como texto", R.drawable.ic_edit) { openFile(e.file, asText = true) }
            }
            if (e.isZip) item("Extraer", R.drawable.ic_zip) { zipOptions(e.file) }
        }
        if (!selected.contains(e.file)) item("Seleccionar", R.drawable.ic_check) { toggle(e.file) }
        item("Copiar", R.drawable.ic_copy) { selected.clear(); selected.addAll(targets); setClip(false) }
        item("Mover", R.drawable.ic_move) { selected.clear(); selected.addAll(targets); setClip(true) }
        if (!multi) item("Renombrar", R.drawable.ic_edit) { renameDialog(e.file) }
        item("Borrar", R.drawable.ic_trash) { deleteDialog(targets) }

        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(6), 0, dp(6))
        box.background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(host.surface())
            setStroke(dp(2), host.border())
        }
        val title = TextView(act)
        title.text = if (multi) "${targets.size} elementos" else e.name
        title.textSize = 12f
        title.setTextColor(muted)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.MIDDLE
        title.setPadding(dp(16), dp(6), dp(16), dp(6))
        box.addView(title)
        for ((label, icon, action) in items) {
            val row = TextView(act)
            row.text = label
            row.textSize = 15f
            row.setTextColor(onSurface)
            row.gravity = Gravity.CENTER_VERTICAL
            row.minHeight = dp(44)
            row.setPadding(dp(16), 0, dp(20), 0)
            AppCompatResources.getDrawable(act, icon)?.mutate()?.let {
                it.setTint(if (label == "Borrar") 0xFFE5484D.toInt() else accent)
                it.setBounds(0, 0, dp(20), dp(20))
                row.setCompoundDrawablesRelative(it, null, null, null)
            }
            row.compoundDrawablePadding = dp(14)
            row.setBackgroundResource(selectableBg())
            row.setOnClickListener {
                dismissMenu()
                action()
            }
            box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val w = dp(230)
        val pw = android.widget.PopupWindow(box, w, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.elevation = dp(12).toFloat()
        pw.isOutsideTouchable = true
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        box.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val screen = act.resources.displayMetrics
        val x = (touchX - w / 2).coerceIn(dp(8), screen.widthPixels - w - dp(8))
        val y = (touchY - dp(12)).coerceIn(dp(24), (screen.heightPixels - box.measuredHeight - dp(24)).coerceAtLeast(dp(24)))
        menu = pw
        pw.showAtLocation(anchor, Gravity.TOP or Gravity.START, x, y)
        anchor.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
    }

    private fun onItemClick(e: FileEntry) {
        when (ExplorerRules.itemAction(pick != null, selected.isNotEmpty(), e.isDir, e.isZip)) {
            ItemAction.OPEN_FOLDER -> navigate(e.file)
            ItemAction.TOGGLE_SELECTION -> toggle(e.file)
            ItemAction.ZIP_OPTIONS -> zipOptions(e.file)
            ItemAction.OPEN_FILE -> openFile(e.file)
        }
    }

    private fun toggle(f: File) {
        if (!selected.remove(f)) selected.add(f)
        adapter.notifyDataSetChanged()
        renderBar()
    }

    // ---------------------------------------------------------------- Lista

    private inner class Holder(val row: LinearLayout, val icon: ImageView, val name: TextView, val sub: TextView, val check: ImageView) :
        RecyclerView.ViewHolder(row)

    // ---- Miniaturas de imágenes y videos (se cargan aparte, a tamaño chico, y se guardan en memoria)
    private val thumbCache = object : android.util.LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 12).toInt().coerceAtMost(48 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val thumbPool = java.util.concurrent.Executors.newFixedThreadPool(3) { r ->
        Thread(r, "fx-thumbs").apply { isDaemon = true }
    }

    private fun loadThumb(f: File, kind: FileKind, px: Int): Bitmap? = try {
        if (kind == FileKind.VIDEO) {
            if (Build.VERSION.SDK_INT >= 29) android.media.ThumbnailUtils.createVideoThumbnail(f, android.util.Size(px, px), null) else null
        } else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, o)
            var sample = 1
            val big = maxOf(o.outWidth, o.outHeight)
            while (big / (sample * 2) >= px) sample *= 2
            val bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bmp == null) null else {
                val rot = when (android.media.ExifInterface(f.absolutePath).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f
                    3 -> 180f
                    8 -> 270f
                    else -> 0f
                }
                if (rot == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
            }
        }
    } catch (_: Throwable) {
        null
    }

    private inner class Adapter : RecyclerView.Adapter<Holder>() {
        override fun getItemCount(): Int = entries.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(8), dp(16), dp(8))
            row.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            val icon = ImageView(act)
            val texts = LinearLayout(act)
            texts.orientation = LinearLayout.VERTICAL
            val name = TextView(act)
            name.textSize = 15f
            name.setTextColor(onSurface)
            name.maxLines = 2
            name.ellipsize = TextUtils.TruncateAt.MIDDLE
            val sub = TextView(act)
            sub.textSize = 12f
            sub.setTextColor(muted)
            sub.maxLines = 1
            texts.addView(name)
            texts.addView(sub)
            val check = ImageView(act)
            check.setImageResource(R.drawable.ic_check)
            check.imageTintList = android.content.res.ColorStateList.valueOf(accent)
            row.addView(icon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginEnd = dp(16) })
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(check, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(8) })
            return Holder(row, icon, name, sub, check)
        }

        /** Ícono por tipo; para imágenes y videos, la miniatura apenas esté lista. */
        private fun bindIcon(h: Holder, e: FileEntry) {
            val thumbKind = !e.isDir && (e.kind == FileKind.IMAGE || e.kind == FileKind.VIDEO) &&
                !e.name.endsWith(".svg", ignoreCase = true)
            val size = dp(if (thumbKind) 44 else 26)
            h.icon.layoutParams = (h.icon.layoutParams as LinearLayout.LayoutParams).apply { width = size; height = size }
            h.icon.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(8).toFloat())
            }
            h.icon.clipToOutline = thumbKind
            h.icon.setImageResource(if (e.isDir) R.drawable.ic_folder else if (e.kind == FileKind.ARCHIVE) R.drawable.ic_zip else R.drawable.ic_file)
            h.icon.imageTintList = android.content.res.ColorStateList.valueOf(e.kind.color)
            h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
            val key = e.file.absolutePath + "|" + e.modified
            h.icon.tag = key
            if (!thumbKind) return
            val show = { b: Bitmap ->
                h.icon.imageTintList = null
                h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
                h.icon.setImageBitmap(b)
            }
            thumbCache.get(key)?.let { show(it); return }
            val px = dp(44) * 2
            thumbPool.execute {
                val b = loadThumb(e.file, e.kind, px) ?: return@execute
                thumbCache.put(key, b)
                h.icon.post { if (h.icon.tag == key) show(b) }
            }
        }

        override fun onBindViewHolder(h: Holder, position: Int) {
            val e = entries[position]
            val on = selected.contains(e.file)
            bindIcon(h, e)
            h.name.text = e.name
            val date = DateFormat.format("d MMM yyyy HH:mm", e.modified).toString()
            h.sub.text = if (e.isDir) "Carpeta · $date" else FileOps.humanSize(e.size) + " · " + date
            h.check.visibility = if (on) View.VISIBLE else View.INVISIBLE
            h.row.setBackgroundColor(if (on) ColorUtils.setAlphaComponent(accent, 0x2A) else Color.TRANSPARENT)
            h.row.setOnClickListener { onItemClick(e) }
            h.row.setOnTouchListener { _, ev ->
                if (ev.actionMasked == android.view.MotionEvent.ACTION_DOWN) {
                    touchX = ev.rawX.toInt()
                    touchY = ev.rawY.toInt()
                }
                false
            }
            h.row.setOnLongClickListener {
                if (pick != null) {
                    if (!e.isDir) toggle(e.file)
                } else {
                    showMenu(h.row, e)
                }
                true
            }
        }
    }
}
