package app.claudeck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Account(
    val id: String,
    var name: String,
    var purpose: String,
    var color: Int,
    /** Momento (epoch ms) hasta el que la cuenta está "descansando" por límite de uso. 0 = disponible. */
    var limitUntil: Long = 0L
) {
    /** Cada cuenta usa un perfil de WebView propio: cookies y datos totalmente separados. */
    val profileName: String get() = "acc_$id"

    fun limitActive(now: Long = System.currentTimeMillis()): Boolean = limitUntil > now

    companion object {
        fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(12)
    }
}

class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("claudeck", Context.MODE_PRIVATE)

    fun load(): List<Account> {
        val raw = prefs.getString("accounts", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Account(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    purpose = o.optString("purpose", ""),
                    color = o.getInt("color"),
                    limitUntil = o.optLong("limitUntil", 0L)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Account>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("name", a.name)
                    .put("purpose", a.purpose)
                    .put("color", a.color)
                    .put("limitUntil", a.limitUntil)
            )
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }

    var selectedId: String?
        get() = prefs.getString("selected", null)
        set(value) {
            prefs.edit().putString("selected", value).apply()
        }
}
