package app.claudeck

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.view.View
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.WindowCompat
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    companion object {
        private const val START_URL = "https://claude.ai/"
        private val PALETTE = listOf(
            "#E07A5F", "#F2A541", "#81B29A", "#4FB0C6",
            "#6C8EAD", "#9A7BD1", "#D96C9F", "#8D99AE"
        ).map { Color.parseColor(it) }
    }

    private lateinit var store: AccountStore
    private val accounts = mutableListOf<Account>()
    private val webViews = HashMap<String, WebView>()
    private val chips = HashMap<String, Chip>()

    private lateinit var container: FrameLayout
    private lateinit var chipGroup: ChipGroup
    private lateinit var chipScroll: HorizontalScrollView
    private lateinit var progress: LinearProgressIndicator
    private lateinit var emptyView: View
    private lateinit var info: TextView

    private var currentId: String? = null
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())

    private val multiProfileOk: Boolean by lazy {
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val uris = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            pendingFileCallback?.onReceiveValue(uris)
            pendingFileCallback = null
        }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        applySystemBars()

        store = AccountStore(this)
        accounts.addAll(store.load())

        container = findViewById(R.id.container)
        chipGroup = findViewById(R.id.chipGroup)
        chipScroll = findViewById(R.id.chipScroll)
        progress = findViewById(R.id.progress)
        emptyView = findViewById(R.id.emptyView)
        info = findViewById(R.id.info)

        findViewById<View>(R.id.btnAddEmpty).setOnClickListener { addAccountFlow() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = currentId?.let { webViews[it] }
                if (wv != null && wv.canGoBack()) {
                    wv.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        rebuildChips()
        val start = store.selectedId?.takeIf { id -> accounts.any { it.id == id } }
            ?: accounts.firstOrNull()?.id
        if (start != null) select(start)
        updateEmptyState()

        if (!multiProfileOk) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Actualizá el WebView")
                .setMessage(
                    "Tu versión de Android System WebView no permite sesiones separadas. " +
                        "Actualizala desde Play Store para poder usar varias cuentas. " +
                        "Mientras tanto solo se puede usar una cuenta."
                )
                .setPositiveButton("Entendido", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        webViews.values.forEach { it.onResume() }
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        webViews.values.forEach { it.onPause() }
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        webViews.values.forEach { wv ->
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        webViews.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun applySystemBars() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }
    }

    private fun dotDrawable(color: Int, selected: Boolean): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        if (selected) {
            val ring = MaterialColors.getColor(
                this, com.google.android.material.R.attr.colorOnSurface, Color.BLACK
            )
            d.setStroke(dp(3), ring)
        }
        return d
    }

    private fun updateEmptyState() {
        val empty = accounts.isEmpty()
        emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        info.visibility = if (empty) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------- Chips

    private fun rebuildChips() {
        chips.clear()
        chipGroup.removeAllViews()
        accounts.forEach { acc ->
            val chip = Chip(this)
            chip.tag = acc.id
            chip.isCheckable = true
            chip.isCheckedIconVisible = false
            val dot = GradientDrawable()
            dot.shape = GradientDrawable.OVAL
            dot.setColor(acc.color)
            dot.setSize(dp(14), dp(14))
            chip.chipIcon = dot
            chip.isChipIconVisible = true
            chip.chipIconSize = dp(14).toFloat()
            chip.chipIconTint = null
            chip.setOnClickListener { select(acc.id) }
            chip.setOnLongClickListener {
                showAccountMenu(acc)
                true
            }
            chips[acc.id] = chip
            chipGroup.addView(chip)
        }
        val add = Chip(this)
        add.text = "Agregar"
        add.chipIcon = AppCompatResources.getDrawable(this, R.drawable.ic_add)
        add.isChipIconVisible = true
        add.setOnClickListener { addAccountFlow() }
        chipGroup.addView(add)
        refreshChipTexts()
        updateSelection()
    }

    private fun refreshChipTexts() {
        accounts.forEach { acc ->
            chips[acc.id]?.text = if (acc.limitActive()) "${acc.name}  ⏳" else acc.name
        }
    }

    private fun updateSelection() {
        chips.forEach { (id, chip) -> chip.isChecked = (id == currentId) }
    }

    private fun updateInfo() {
        val acc = accounts.firstOrNull { it.id == currentId }
        if (acc == null) {
            info.text = ""
            return
        }
        val parts = mutableListOf(acc.name)
        if (acc.purpose.isNotBlank()) parts.add(acc.purpose)
        if (acc.limitActive()) {
            val until = DateFormat.format("EEE HH:mm", acc.limitUntil)
            val left = formatRemaining(acc.limitUntil - System.currentTimeMillis())
            parts.add("En descanso hasta $until (faltan $left)")
        } else {
            parts.add("Disponible")
        }
        info.text = parts.joinToString(" · ")
    }

    private fun formatRemaining(ms: Long): String {
        val totalMin = (ms / 60_000L).coerceAtLeast(1L)
        val days = totalMin / (60 * 24)
        val hours = (totalMin % (60 * 24)) / 60
        val mins = totalMin % 60
        return when {
            days > 0 -> "$days d $hours h"
            hours > 0 -> "$hours h $mins min"
            else -> "$mins min"
        }
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        var changed = false
        accounts.forEach { a ->
            if (a.limitUntil in 1L..now) {
                a.limitUntil = 0L
                changed = true
                Toast.makeText(this, "«${a.name}» ya puede usarse de nuevo", Toast.LENGTH_LONG).show()
            }
        }
        if (changed) store.save(accounts)
        refreshChipTexts()
        updateInfo()
    }

    // ---------------------------------------------------------------- Selección y WebViews

    private fun select(id: String) {
        val acc = accounts.firstOrNull { it.id == id } ?: return
        currentId = id
        store.selectedId = id
        val wv = webViews.getOrPut(id) { createWebView(acc) }
        webViews.forEach { (k, v) -> v.visibility = if (k == id) View.VISIBLE else View.GONE }
        progress.visibility = View.INVISIBLE
        updateSelection()
        updateInfo()
        chips[id]?.let { chip -> chipScroll.post { chipScroll.smoothScrollTo(chip.left - dp(16), 0) } }
        wv.requestFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(acc: Account): WebView {
        val wv = WebView(this)
        wv.tag = acc.id
        if (multiProfileOk) {
            // Perfil propio: cookies, almacenamiento y caché separados por cuenta.
            ProfileStore.getInstance().getOrCreateProfile(acc.profileName)
            WebViewCompat.setProfile(wv, acc.profileName)
        }
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            mediaPlaybackRequiresUserGesture = true
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                }
                return true
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (view?.tag != currentId) return
                progress.setProgressCompat(newProgress, true)
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.INVISIBLE
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                return try {
                    fileLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    pendingFileCallback = null
                    filePathCallback.onReceiveValue(null)
                    false
                }
            }
        }
        wv.setDownloadListener { url, _, _, _, _ ->
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {
            }
        }
        container.addView(wv, 0)
        wv.loadUrl(START_URL)
        return wv
    }

    // ---------------------------------------------------------------- Cuentas

    private fun addAccountFlow() {
        if (!multiProfileOk && accounts.isNotEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Falta actualizar el WebView")
                .setMessage("Para usar más de una cuenta hay que actualizar Android System WebView desde Play Store.")
                .setPositiveButton("Entendido", null)
                .show()
            return
        }
        showAccountDialog(null)
    }

    private fun showAccountDialog(existing: Account?) {
        val v = layoutInflater.inflate(R.layout.dialog_account, null)
        val inName = v.findViewById<TextInputEditText>(R.id.inputName)
        val inPurpose = v.findViewById<TextInputEditText>(R.id.inputPurpose)
        val row = v.findViewById<LinearLayout>(R.id.colorRow)
        var color = existing?.color ?: PALETTE[accounts.size % PALETTE.size]
        inName.setText(existing?.name ?: "")
        inPurpose.setText(existing?.purpose ?: "")

        val dots = mutableListOf<Pair<Int, View>>()
        fun paint() {
            dots.forEach { (c, view) -> view.background = dotDrawable(c, c == color) }
        }
        PALETTE.forEach { c ->
            val dot = View(this)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            dot.layoutParams = lp
            dot.setOnClickListener {
                color = c
                paint()
            }
            row.addView(dot)
            dots.add(c to dot)
        }
        paint()

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "Nueva cuenta" else "Editar cuenta")
            .setView(v)
            .setPositiveButton("Guardar", null)
            .setNegativeButton("Cancelar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = inName.text?.toString()?.trim().orEmpty()
                if (name.isEmpty()) {
                    inName.error = "Poné un nombre"
                    return@setOnClickListener
                }
                val purpose = inPurpose.text?.toString()?.trim().orEmpty()
                if (existing == null) {
                    val acc = Account(Account.newId(), name, purpose, color)
                    accounts.add(acc)
                    store.save(accounts)
                    rebuildChips()
                    updateEmptyState()
                    select(acc.id)
                } else {
                    existing.name = name
                    existing.purpose = purpose
                    existing.color = color
                    store.save(accounts)
                    rebuildChips()
                    updateInfo()
                }
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showAccountMenu(acc: Account) {
        val items = arrayOf(
            "Editar nombre, propósito o color",
            "Recargar",
            "Marcar límite alcanzado…",
            "Quitar marca de límite",
            "Cerrar sesión y borrar datos",
            "Eliminar cuenta"
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(acc.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showAccountDialog(acc)
                    1 -> webViews[acc.id]?.reload() ?: select(acc.id)
                    2 -> showLimitDialog(acc)
                    3 -> setLimit(acc, 0L)
                    4 -> confirm(
                        "Cerrar sesión",
                        "Se cierra la sesión de «${acc.name}» y se borran sus cookies y datos en este dispositivo."
                    ) { wipeAccount(acc, remove = false) }
                    5 -> confirm(
                        "Eliminar cuenta",
                        "Se quita «${acc.name}» de la app y se borran sus datos en este dispositivo. Tu cuenta de Claude no se toca."
                    ) { wipeAccount(acc, remove = true) }
                }
            }
            .show()
    }

    private fun confirm(title: String, message: String, onYes: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Sí") { _, _ -> onYes() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- Límites de uso

    private fun showLimitDialog(acc: Account) {
        val hour = 60 * 60 * 1000L
        val items = arrayOf("Dentro de 5 horas", "Dentro de 24 horas", "Dentro de 7 días", "A una hora exacta…")
        MaterialAlertDialogBuilder(this)
            .setTitle("¿Cuándo se reinicia el límite?")
            .setItems(items) { _, which ->
                val now = System.currentTimeMillis()
                when (which) {
                    0 -> setLimit(acc, now + 5 * hour)
                    1 -> setLimit(acc, now + 24 * hour)
                    2 -> setLimit(acc, now + 7 * 24 * hour)
                    3 -> pickExactTime(acc)
                }
            }
            .show()
    }

    private fun pickExactTime(acc: Account) {
        val now = Calendar.getInstance()
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_24H)
            .setHour(now.get(Calendar.HOUR_OF_DAY))
            .setMinute(now.get(Calendar.MINUTE))
            .setTitleText("Hora en que se reinicia")
            .build()
        picker.addOnPositiveButtonClickListener {
            val target = Calendar.getInstance()
            target.set(Calendar.HOUR_OF_DAY, picker.hour)
            target.set(Calendar.MINUTE, picker.minute)
            target.set(Calendar.SECOND, 0)
            target.set(Calendar.MILLISECOND, 0)
            if (target.timeInMillis <= System.currentTimeMillis()) {
                target.add(Calendar.DAY_OF_YEAR, 1)
            }
            setLimit(acc, target.timeInMillis)
        }
        picker.show(supportFragmentManager, "limit_time")
    }

    private fun setLimit(acc: Account, until: Long) {
        acc.limitUntil = until
        store.save(accounts)
        refreshChipTexts()
        updateInfo()
    }

    // ---------------------------------------------------------------- Borrado

    private fun wipeAccount(acc: Account, remove: Boolean) {
        webViews.remove(acc.id)?.let { wv ->
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        if (multiProfileOk) {
            try {
                ProfileStore.getInstance().deleteProfile(acc.profileName)
            } catch (e: Exception) {
                // Si el perfil sigue "en uso", al menos vaciamos cookies y almacenamiento.
                try {
                    val p = ProfileStore.getInstance().getProfile(acc.profileName)
                    p?.cookieManager?.removeAllCookies(null)
                    p?.webStorage?.deleteAllData()
                } catch (_: Exception) {
                }
            }
        }
        if (remove) {
            accounts.removeAll { it.id == acc.id }
            store.save(accounts)
            rebuildChips()
            updateEmptyState()
            if (currentId == acc.id) {
                currentId = null
                val next = accounts.firstOrNull()?.id
                if (next != null) select(next) else {
                    store.selectedId = null
                    updateInfo()
                }
            }
        } else {
            select(acc.id)
        }
    }
}
